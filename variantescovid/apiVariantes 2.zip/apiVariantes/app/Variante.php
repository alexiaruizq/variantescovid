<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Variante extends Model
{
    protected $table = "variants";
}
